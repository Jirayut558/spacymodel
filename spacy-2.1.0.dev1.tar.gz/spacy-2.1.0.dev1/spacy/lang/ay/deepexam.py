import deepcut
print(deepcut.tokenize('ผมเป็นคนขอนแก่น'))