# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.sv.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple överväger att köpa brittisk startup för 1 miljard dollar.",
    "Självkörande bilar förskjuter försäkringsansvar mot tillverkare.",
    "San Fransisco överväger förbud mot leveransrobotar på trottoarer.",
    "London är en storstad i Storbritannien."
]
